//
//  Desafio01App.swift
//  Desafio01
//
//  Created by Turma02-10 on 05/02/25.
//

import SwiftUI

@main
struct Desafio01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
