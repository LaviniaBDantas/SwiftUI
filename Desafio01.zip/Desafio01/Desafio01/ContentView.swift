//
//  ContentView.swift
//  Desafio01
//
//  Created by Turma02-10 on 05/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HStack{
                Rectangle().size(/*@START_MENU_TOKEN@*/CGSize(width: 100.0, height: 100.0)/*@END_MENU_TOKEN@*/).foregroundColor(.red)
                Spacer(minLength: 160)
                Rectangle().size(/*@START_MENU_TOKEN@*/CGSize(width: 100.0, height: 100.0)/*@END_MENU_TOKEN@*/).foregroundColor(.blue)
            }
            Spacer(minLength: 550)
            HStack{
                Rectangle().size(/*@START_MENU_TOKEN@*/CGSize(width: 100.0, height: 100.0)/*@END_MENU_TOKEN@*/).foregroundColor(.green)
                Spacer(minLength: 160)
                Rectangle().size(/*@START_MENU_TOKEN@*/CGSize(width: 100.0, height: 100.0)/*@END_MENU_TOKEN@*/).foregroundColor(.yellow)
            }



        }
        .padding()
    }
}

#Preview {
    ContentView()
}
