//
//  SegundaTela.swift
//  Desafio08
//
//  Created by Turma02-10 on 12/02/25.
//

import SwiftUI

struct SegundaTela: View {
    var musica: Song
    var body: some View {
        ZStack{
            LinearGradient(gradient: Gradient(colors: [.blue, .black]), startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            VStack{
                Spacer()
                AsyncImage(url: URL(string: musica.capa)) { image in image.resizable()
                        .aspectRatio(contentMode: .fill)
                } placeholder: {
                    Color.gray
                }
                .frame(width: 200, height: 200)
                HStack{
                    Text(musica.name).foregroundColor(.white).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                }
                HStack{
                    Text(musica.artist).foregroundColor(.white)
                }
                Spacer()
                HStack{
                    Image(systemName: "shuffle").foregroundColor(.white).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    Image(systemName: "backward.end.fill").foregroundColor(.white).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    Image(systemName: "play.fill").foregroundColor(.white).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    Image(systemName: "forward.end.fill").foregroundColor(.white).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    Image(systemName: "repeat").foregroundColor(.white).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)

                }
                Spacer()
                
            }
            
        }
    }
}

#Preview {
    SegundaTela(musica:  Song(id:0, name: "Teste", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg"))
}
