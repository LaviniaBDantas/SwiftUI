//
//  ContentView.swift
//  Desafio08
//
//  Created by Turma02-10 on 12/02/25.
//
struct Song : Identifiable {
    var id: Int
    var name: String
    var artist: String
    var capa: String
}

var arrayMusicas=[
    Song(id:0, name: "Valerie", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg"),
    Song(id:1, name: "Valerie", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg"),
    Song(id:2, name: "Valerie", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg"),
    Song(id:3, name: "Valerie", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg"),
    Song(id:4, name: "Valerie", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg"),
    Song(id:5, name: "Valerie", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg"),
    Song(id:6, name: "Valerie", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg"),
    Song(id:7, name: "Valerie", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg"),
    Song(id:8, name: "Valerie", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg"),
    Song(id:9, name: "Valerie", artist: "Amy Winehouse",capa:"https://m.media-amazon.com/images/I/61j+s0YtybL._UF1000,1000_QL80_.jpg")
    
]

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        NavigationStack{
            
            ZStack{
                LinearGradient(gradient: Gradient(colors: [.blue, .black]), startPoint: .top, endPoint: .bottom).ignoresSafeArea()
                ScrollView{
                    VStack {
                        //            AsyncImage(url: URL(string: "https://portais.univasf.edu.br/imagens-noticias/WhatsAppImage20240910at17.01.29.jpeg"))
                        HStack{
                            Spacer()
                            AsyncImage(url: URL(string: "https://portais.univasf.edu.br/imagens-noticias/WhatsAppImage20240910at17.01.29.jpeg")) { image in image.resizable()
                                    .aspectRatio(contentMode: .fill)
                            } placeholder: {
                                Color.gray
                            }
                            .frame(width: 200, height: 200)
                            Spacer()
                        }.padding()
                        HStack{
                            Text("HackaFM").bold().font(.title).foregroundColor(.white)
                            Spacer()
                        }.padding(.horizontal, 20)
                        HStack{
                            Text("HackaUser").bold().foregroundColor(.white)
                            Spacer()
                        }.padding(.horizontal,20)
                        
                        ForEach(arrayMusicas) { musica in
                            NavigationLink(destination: SegundaTela(musica: musica)){
                                AsyncImage(url: URL(string: musica.capa)) { image in image.resizable()
                                        .aspectRatio(contentMode: .fit)                                                .frame(width: 60, height: 60)
                                        .padding(.leading)
                                } placeholder: {
                                    Color.gray
                                }
                                VStack(alignment: .leading){
                                    Text(musica.name).foregroundColor(.white).bold()
                                    Text(musica.artist).foregroundColor(.white)
                                }
                                Spacer()
                                Image(systemName: "ellipsis").foregroundColor(.white).padding(.trailing)
                                
                                
                            }
                        }
                        Spacer()
                        HStack{                                Text("Sugeridos").foregroundColor(.white).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).padding().bold()
                            Spacer()
                        }
                        ScrollView(.horizontal){
                            
                            HStack(spacing: 20){
                                ForEach(arrayMusicas) { musica in
                                    VStack{
                                        AsyncImage(url: URL(string: musica.capa)) { image in image.resizable()
                                                .aspectRatio(contentMode: .fit)                                                .frame(width: 200, height: 200)
                                                .padding(.leading)
                                        } placeholder: {
                                            Color.gray
                                        }
                                        HStack{
                                            Text(musica.name).foregroundColor(.white)}
                                    }
                                }
                            }
                        }
                        
                    }
                }
                
                
                
                
                //.padding()
            }
        }.tint(.white)
    }
}

#Preview {
    ContentView()
}
