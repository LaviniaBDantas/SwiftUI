//
//  Desafio08App.swift
//  Desafio08
//
//  Created by Turma02-10 on 12/02/25.
//

import SwiftUI

@main
struct Desafio08App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
