//
//  Desafio04App.swift
//  Desafio04
//
//  Created by Turma02-10 on 07/02/25.
//

import SwiftUI

@main
struct Desafio04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
