//
//  ContentView.swift
//  Desafio04
//
//  Created by Turma02-10 on 07/02/25.
//

import SwiftUI

struct ContentView: View {
    @State var teste = false
    @State private var name: String = ""
    var body: some View {
        VStack {
            
            ZStack(){
                Image("fundo").resizable().scaledToFill().opacity(0.20).ignoresSafeArea()
                VStack(){
                    Text("Bem vindo(a), \(name)!").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    TextField("Digite seu nome", text: $name).multilineTextAlignment(.center)
                    Spacer()
                    Image("logo").resizable().scaledToFit()
                        .frame(width: 300).shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                    Image("truck").resizable().scaledToFit().frame(width: 200).shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                    Spacer()
                    
                    Button("Entrar") {
                                teste = true
                            }
                    .alert(isPresented: $teste) {
                                Alert(title: Text("ALERTA"), message: Text("Você irá iniciar o desafio da aula agora"), dismissButton: .default(Text("Vamos lá!")))
                            }
                    
                    
                }

               
            }
            

                }
    }
}

#Preview {
    ContentView()
}
