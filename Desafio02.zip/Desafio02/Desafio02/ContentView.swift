//
//  ContentView.swift
//  Desafio02
//
//  Created by Turma02-10 on 05/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HStack{
                Image("img").resizable().frame(width: 200, height: 200).clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                Spacer()
                VStack{
                    Text("HackaTruck").foregroundColor(.red).bold()
                    Text("77 universidades").foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/).bold()
                    Text("5 regiões do Brasil").foregroundColor(.yellow).bold()
                }
            }

        }
        .padding()
    }
}

#Preview {
    ContentView()
}
