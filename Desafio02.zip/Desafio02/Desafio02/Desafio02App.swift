//
//  Desafio02App.swift
//  Desafio02
//
//  Created by Turma02-10 on 05/02/25.
//

import SwiftUI

@main
struct Desafio02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
