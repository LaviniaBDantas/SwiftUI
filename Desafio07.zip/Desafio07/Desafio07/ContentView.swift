//
//  ContentView.swift
//  Desafio07
//
//  Created by Turma02-10 on 11/02/25.
//

import SwiftUI

struct SheetView: View {
    @Environment(\.dismiss) var dismiss
    
    @State var fundo : Color = .escuro
    var body: some View {
        
        ZStack{
            fundo.ignoresSafeArea()
            VStack{
                Text("Sheet View").foregroundColor(.white).bold().font(.title).padding()
                Spacer()
                Text("Nome: Lavínia\nSobrenome:Barbosa").bold().foregroundColor(.white)
                    .frame(width: 200.0, height: 100.0)
                    .background(.pink)
                    .cornerRadius(4.0)
                Spacer()
            }
            
            
        }
    }
}
struct ContentView: View {
    @State var fundo : Color = .escuro
    @State private var showingSheet = false
    var body: some View {
        NavigationStack{
            ZStack{
                fundo.ignoresSafeArea()
                VStack{
                    Image("logo").resizable().scaledToFit()
                    Spacer()
                    NavigationLink(destination: SegundaTela()){
                        ZStack{
                            Text("Modo 1").foregroundColor(.white)
                                .frame(width: 200.0, height: 61.0)
                                .background(.pink)
                                .cornerRadius(4.0)
                        }
                    }
                    
                    NavigationLink(destination: TerceiraTela()){
                        ZStack{
                            Text("Modo 2")
                                .foregroundColor(.white)
                                    .frame(width: 200.0, height: 61.0)
                                    .background(.pink)
                                    .cornerRadius(4.0)
                        }
           
                    }
                    
                    
                    Button("Modo 3") {
                        showingSheet.toggle()
                    }.foregroundColor(.white)
                        .frame(width: 200.0, height: 61.0)
                        .background(.pink)
                        .cornerRadius(4.0).sheet(isPresented: $showingSheet){
                            SheetView()
                        }
                    Spacer()
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
