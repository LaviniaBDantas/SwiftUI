//
//  QuartaTela.swift
//  Desafio07
//
//  Created by Turma02-10 on 11/02/25.
//

import SwiftUI

struct QuartaTela: View {
    @State var fundo : Color = .escuro
    var nome: String
    var body: some View {
        
        ZStack{
            fundo.ignoresSafeArea()
            VStack{
                Text("Modo 2").foregroundColor(.white).bold().font(.title)
                Spacer()
                Text("Volte, \n \(nome)!!").padding().bold().foregroundColor(.white)
                    .font(.system(size: 30))
                    .background(.pink)
                    .cornerRadius(9.0)
                Spacer()
            }
            
            
        }
    }
}

#Preview {
    QuartaTela(nome: "Teste")
}
