//
//  SegundaTela.swift
//  Desafio07
//
//  Created by Turma02-10 on 11/02/25.
//

import SwiftUI

struct SegundaTela: View {
    @State var fundo : Color = .escuro
    var body: some View {
        
        ZStack{
            fundo.ignoresSafeArea()
            VStack{
                Text("Modo 1").foregroundColor(.white).bold().font(.title)
                Spacer()
                Text("Nome: Lavínia\nSobrenome:Barbosa").bold().foregroundColor(.white)
                    .frame(width: 200.0, height: 100.0)
                    .background(.pink)
                    .cornerRadius(4.0)
                Spacer()
            }
            
            
        }
    }
}

#Preview {
    SegundaTela()
}
