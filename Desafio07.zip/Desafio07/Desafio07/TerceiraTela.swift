//
//  TerceiraTela.swift
//  Desafio07
//
//  Created by Turma02-10 on 11/02/25.
//

import SwiftUI

struct TerceiraTela: View {
    @State private var name: String = ""
    @State var fundo : Color = .escuro
    var body: some View {
        
        ZStack{
            fundo.ignoresSafeArea()
            VStack{
                Text("Modo 2").foregroundColor(.white).bold().font(.title)
                Spacer()
                VStack{
                    TextField("Digite seu nome", text: $name).multilineTextAlignment(.center).foregroundColor(.white)
                    Text("Bem vindo(a), \(name)!").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).foregroundColor(.white).bold()
                    
                    NavigationLink(destination: QuartaTela(nome:name)){
                        
                        Text("Acessar Tela")
                            .padding()
                            .foregroundColor(.white)
                            .background(.blue)
                            .cornerRadius(17.0)
                        
                        
                    }
                    
                }.padding()
                    .background(.pink)
                    .cornerRadius(40)
                    .padding()
                Spacer()
            }
            
        }
    }
}

#Preview {
    TerceiraTela()
}
