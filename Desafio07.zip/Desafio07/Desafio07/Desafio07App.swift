//
//  Desafio07App.swift
//  Desafio07
//
//  Created by Turma02-10 on 11/02/25.
//

import SwiftUI

@main
struct Desafio07App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
