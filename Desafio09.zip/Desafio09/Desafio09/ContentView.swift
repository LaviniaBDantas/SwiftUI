//
//  ContentView.swift
//  Desafio09
//
//  Created by Turma02-10 on 13/02/25.
//
import MapKit
import SwiftUI

struct Location: Hashable{
    let nome : String
    let foto : String
    let descricao : String
    let latitude : Double
    let longitude : Double
}

var locais=[
    Location(nome: "Montes Claros", foto: "https://www.viagensecaminhos.com/wp-content/uploads/2024/06/montes-claros.jpg", descricao: "Montes Claros é um município brasileiro no norte do estado de Minas Gerais. Localiza-se a norte da capital do estado, distando desta cerca de 422 km. Ocupa uma área de 3 589,811 km², sendo que 73,51 km² estão em perímetro urbano. Sua população em 2022 era de 414 240 habitantes, posicionando-se como o quinto mais populoso do estado mineiro. Montes Claros foi emancipada no século XIX, tendo, há bastante tempo, a indústria e o comércio como importantes atividades econômicas, sendo considerada um polo industrial regional. Atualmente é formada por dez distritos e subdividida ainda em cerca de 200 bairros e povoados.[7] Conta com diversos atrativos naturais, históricos ou culturais, como os Parques Municipal Milton Prates, Guimarães Rosa e Sapucaia, que são importantes áreas verdes, e construções como a Catedral de Nossa Senhora Aparecida e a Igrejinha dos Morrinhos, além dos vários sítios arqueológicos.[8]", latitude: -16.7280921, longitude: -43.8510828),
    Location(nome: "Belo Horizonte", foto: "https://encrypted-tbn3.gstatic.com/licensed-image?q=tbn:ANd9GcT7-TWcj02BQWl-sSptDOxiPUwb4loY9xJU-1K5qAwD06F0SXVpCBSPMdWJQar2j7sl0gC6MUj12VZZSIrnvKENwmmxLC82EJ4V0pL7VQ", descricao: "Belo Horizonte é a capital do estado de Minas Gerais, no sudeste do Brasil. Rodeada de montanhas, a cidade é conhecida pelo enorme Estádio Mineirão. Construído em 1965, o estádio alberga também o Museu Brasileiro do Futebol. Nas proximidades encontra-se a Lagoa da Pampulha e o Conjunto Arquitetónico da Pampulha, que inclui a Igreja de São Francisco de Assis, cujo teto é ondulado e que foi concebida pelo arquiteto modernista brasileiro Oscar Niemeyer.", latitude: -19.9026404, longitude: -44.1288611)]

struct SheetView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var selecionado : Location
    var fundo : Color = .color
    
    
    
    var body: some View {
        ZStack{
            fundo.ignoresSafeArea()
            VStack{
                HStack{
                    Spacer()
                    AsyncImage(url: URL(string: selecionado.foto)) { image in image.resizable()
                            .aspectRatio(contentMode: .fit)
                    } placeholder: {
                        Color.gray
                    }
                    .frame(width: 300, height: 300)
                    Spacer()
                }
                HStack{
                    Text(selecionado.nome).foregroundColor(.brown).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).bold()
                    
                }
                HStack{
                    Text(selecionado.descricao).padding().background(.brown)
                }.padding()
                Spacer()

            }
        }}
}

struct ContentView: View {
    @State private var showingSheet = false
    @State private var selecionado = Location(nome: "Montes Claros", foto: "https://www.viagensecaminhos.com/wp-content/uploads/2024/06/montes-claros.jpg", descricao: "Montes Claros é um município brasileiro no norte do estado de Minas Gerais. Localiza-se a norte da capital do estado, distando desta cerca de 422 km.", latitude: -16.7280921, longitude: -43.8510828)
    
    @State private var position = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 51.507222, longitude: -0.1275),
            span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1)
        )
    )
    var body: some View {
        VStack {
            ZStack{
                Map(position: $position){
                    ForEach(locais, id: \.self){
                        l in
                        Annotation(l.nome, coordinate: CLLocationCoordinate2D(latitude: l.latitude, longitude: l.longitude)) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 5)
                                    .fill(Color.teal)
                                Image(systemName: "eyedropper.full")
                                    .padding(5)
                                
                            }.onTapGesture(){
                                showingSheet.toggle()
                            }
                        }
                    }

                }.ignoresSafeArea()
                    .sheet(isPresented: $showingSheet) {
                        SheetView(selecionado: $selecionado)
                    }
                VStack{
                    
                    //                  HStack{
                    Picker("Escolha a cidade", selection: $selecionado) {
                        ForEach(locais, id: \.self) { l in
                            Text(l.nome)
                            
                            
                            
                        }
                        
                    }.frame(width: 200, height: 80)
                        .background().colorMultiply(.color)
                        .cornerRadius(20)
                    Spacer()
                } .onChange(of: selecionado){
                    position = MapCameraPosition.region(
                        MKCoordinateRegion(
                            center: CLLocationCoordinate2D(latitude: selecionado.latitude, longitude: selecionado.longitude),
                            span: MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1)
                        )
                    )
                }
                
                
                
            }
            //.padding()
        }
    }
}


#Preview {
    ContentView()
}

