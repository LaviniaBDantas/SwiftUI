//
//  Desafio09App.swift
//  Desafio09
//
//  Created by Turma02-10 on 13/02/25.
//

import SwiftUI

@main
struct Desafio09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
