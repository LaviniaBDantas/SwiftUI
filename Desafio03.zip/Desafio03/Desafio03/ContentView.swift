//
//  ContentView.swift
//  Desafio03
//
//  Created by Turma02-10 on 06/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            HStack{
                
                VStack{
                    Image(systemName: "person.crop.circle.fill").font(.system(size: 100))
                }
                Spacer()
                
                VStack{
                    HStack{
                        VStack{
                            Text("8 \n posts").bold(true).multilineTextAlignment(.center)
                        }
                        Spacer()
                        VStack{
                            Text("12k \n seguidores").bold(true).multilineTextAlignment(.center)
                            
                        }
                        Spacer()
                        VStack{
                            Text("2k \n seguindo").bold(true).multilineTextAlignment(.center)
                        }
                    }
                    HStack{
                        Button("Editar Perfil", action: {
                            print("teste")
                        })
                    }.padding(.top, 20)
                }
            }
            VStack(alignment: .leading){
                HStack{
                    Text("Nome Sobrenome").bold(true)
                }
                HStack{
                    Text("Lorem ipsum dolor sit amet")
                    Spacer()
                }
                
            }
            
            .padding(.vertical, 20)
            
            HStack(spacing: 80){
                VStack{
                    Image(systemName: "square.grid.3x3.square").font(.system(size: 35))
                }
                
                VStack{
                    Image(systemName: "rectangle.stack").font(.system(size: 35))

                }
               
                VStack{
                    Image(systemName: "person.crop.square.fill").font(.system(size: 35))
                }
                
            }
            HStack(){
                VStack{
    
                    Rectangle().foregroundColor(.gray)
                }
                VStack{
                    Rectangle().foregroundColor(.gray)
                }
                VStack{
                    Rectangle().foregroundColor(.gray)
                }
                
            }
            HStack{
                VStack{
                    Rectangle().foregroundColor(.gray)
                }
                VStack{
                    Rectangle().foregroundColor(.gray)
                }
                VStack{
                    Rectangle().foregroundColor(.gray)
                }
            }
            HStack{
                VStack{
                    Rectangle().foregroundColor(.gray)
                }
                VStack{
                    Rectangle().foregroundColor(.gray)
                }
                VStack{
                    Rectangle().foregroundColor(.gray)
                }
            }
            
            
            
        }
        
        
        .padding()
    }
}

#Preview {
    ContentView()
}
