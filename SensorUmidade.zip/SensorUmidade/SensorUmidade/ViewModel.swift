//
//  ViewModel.swift
//  SensorUmidade
//
//  Created by Turma02-10 on 24/02/25.
//

import Foundation
class ViewModel : ObservableObject{
    @Published var arrayUmidade : [Umidade] = []
    func fetch(){
        let url = "http://192.168.128.81:1880/get"
        let task = URLSession.shared.dataTask(with: URL(string: url)!){
            data,_,error in
            
            do{
                self.arrayUmidade =  try JSONDecoder().decode([Umidade].self, from: data!).sorted(by: {$0.dataHora>$1.dataHora})
            }catch{
                print(error)
            }
        }
        task.resume()
    }
}
