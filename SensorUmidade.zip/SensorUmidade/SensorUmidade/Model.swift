//
//  Model.swift
//  SensorUmidade
//
//  Created by Turma02-10 on 24/02/25.
//

import Foundation
struct Umidade : Decodable,Hashable {
    var _id : String
    var _rev : String
    var umidade : String
    var dataHora : Int
}
