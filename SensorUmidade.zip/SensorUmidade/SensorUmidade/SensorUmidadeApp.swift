//
//  SensorUmidadeApp.swift
//  SensorUmidade
//
//  Created by Turma02-10 on 24/02/25.
//

import SwiftUI

@main
struct SensorUmidadeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
