//
//  ContentView.swift
//  SensorUmidade
//
//  Created by Turma02-10 on 24/02/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var vm = ViewModel()
    var body: some View {
        ScrollView{
            VStack {
                ForEach(vm.arrayUmidade, id:\.self){ u in
                    Text(u.umidade)
                    
                }
            }.onAppear(){
               Timer.scheduledTimer(withTimeInterval: 1, repeats: true){ _ in
                    vm.fetch()
                }
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
