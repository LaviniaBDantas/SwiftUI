//
//  CinzaView.swift
//  Desafio06
//
//  Created by Turma02-10 on 11/02/25.
//

import SwiftUI

struct CinzaView: View {
    @State var fundo : Color = .gray
    var body: some View {
        ZStack{
            fundo.edgesIgnoringSafeArea(.top)
            Circle().scaleEffect(0.8)
            Image(systemName: "paintpalette").foregroundColor(.gray).scaleEffect(10)
        }
        
    }
}

#Preview {
    CinzaView()
}
