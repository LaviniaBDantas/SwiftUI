//
//  RosaView.swift
//  Desafio06
//
//  Created by Turma02-10 on 11/02/25.
//

import SwiftUI

struct RosaView: View {
    @State var fundo : Color = .pink
    var body: some View {
        ZStack{
            fundo.edgesIgnoringSafeArea(.top)
            Circle().scaleEffect(0.8)
            Image(systemName: "paintbrush").foregroundColor(.pink).scaleEffect(10)
        }
        
    }
}

#Preview {
    RosaView()
}
