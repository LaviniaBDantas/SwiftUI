//
//  ContentView.swift
//  Desafio06
//
//  Created by Turma02-10 on 11/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
//        VStack {
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundStyle(.tint)
//            Text("Hello, world!")
//        }
        TabView{
            RosaView()
                .tabItem{
                    Label("Rosa", systemImage: "paintbrush.fill")
                }
            AzulView()
                .tabItem{
                    Label("Azul", systemImage: "paintbrush.pointed.fill")
                }
            CinzaView()
                .tabItem{
                    Label("Cinza", systemImage: "paintpalette.fill")
                    
                }
            ListaView()
                .tabItem{
                    Label("Lista", systemImage: "list.bullet")
                }
        }
        //.padding()
    }

}

#Preview {
    ContentView()
}
