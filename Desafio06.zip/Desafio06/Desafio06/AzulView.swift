//
//  AzulView.swift
//  Desafio06
//
//  Created by Turma02-10 on 11/02/25.
//

import SwiftUI

struct AzulView: View {
    @State var fundo : Color = .blue
    var body: some View {
        ZStack{
            fundo.edgesIgnoringSafeArea(.top)
            Circle().scaleEffect(0.8)
            Image(systemName: "paintbrush.pointed").foregroundColor(.blue).scaleEffect(10)
        }
        
    }
}

#Preview {
    AzulView()
}
