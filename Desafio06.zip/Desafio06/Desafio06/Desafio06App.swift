//
//  Desafio06App.swift
//  Desafio06
//
//  Created by Turma02-10 on 11/02/25.
//

import SwiftUI

@main
struct Desafio06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
