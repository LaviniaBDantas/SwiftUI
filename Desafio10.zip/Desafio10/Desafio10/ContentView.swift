//
//  ContentView.swift
//  Desafio10
//
//  Created by Turma02-10 on 17/02/25.
//

import SwiftUI

struct SheetView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var personagem : String
    var body: some View {
        ZStack{
            Color.brown.ignoresSafeArea()
            VStack{
                Text(personagem).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).padding().foregroundColor(.white).bold().background(.ultraThinMaterial).cornerRadius(10.0)
            }
        }
    }
}

struct ContentView: View {
    @StateObject var vm = ViewModel()
    @State var  personagem = ""
    @State private var showingSheet = false
    var body: some View {
        ZStack{
            Image("fundoGame").resizable()
            VStack {
                HStack{
                    Spacer()
                    Button{
                        personagem = ""
                        vm.fetch()
                    }label:{
                        Image(systemName: "arrow.clockwise.circle.fill").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).foregroundColor(.white)
                    }
                }
                Spacer()
                
                ForEach(vm.arrayQuote, id:\.self){ quote in
                    Text(quote.sentence).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).padding().foregroundColor(.white).bold().background(.ultraThinMaterial).cornerRadius(10.0)
                }
                Button("Quem disse?") {
                    personagem = (vm.arrayQuote.first?.character.name)!
                    showingSheet.toggle()
                }.font(.title2).bold().buttonStyle(.borderedProminent)
                    .tint(.brown).sheet(isPresented: $showingSheet) {
                    SheetView(personagem: $personagem)
                }
                Spacer()
                //.foregroundColor(.white).buttonStyle(.bordered)
            }.onAppear(){
                vm.fetch()
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
