//
//  Desafio10App.swift
//  Desafio10
//
//  Created by Turma02-10 on 17/02/25.
//

import SwiftUI

@main
struct Desafio10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
