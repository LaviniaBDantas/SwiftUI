//
//  ContentView.swift
//  Desafio05
//
//  Created by Turma02-10 on 10/02/25.
//

import SwiftUI

struct ContentView: View {
    @State  var distancia : Double  = 0.0
    @State var tempo : Double = 0.0
    @State var velocidade : Double = 0.0
    @State var img : String = "interroga"
    @State var fundo : Color = .gray
    
    var body: some View {
        ZStack{
            fundo.ignoresSafeArea()
            
            VStack {
                Text("Digite a distância(km)")
                TextField("Digite a distância(km)", value: $distancia, format: .number).multilineTextAlignment(.center).frame(width: 150).background(Color.white)
                Text("Digite o tempo (h)")
                TextField("Digite o tempo(h)", value: $tempo, format: .number).multilineTextAlignment(.center).cornerRadius(10).frame(width: 150).cornerRadius(10.0).background(Color.white)
                
                
                
                Button("Calcular", action: {
                    velocidade = (distancia/tempo)
                    
                    switch velocidade {
                    case ((0.0  ... 9.9)):
                        img = "tartaruga2"
                        fundo = .tartaruga
                    case (10.0 ... 29.9):
                        img="elefante"
                        fundo = .elefante
                    case (30 ... 69.9):
                        img="aves"
                        fundo = .avestruz
                    case(70 ... 89.9):
                        img="leao"
                        fundo = .leao
                    case(90 ... 130):
                        img="guepardo"
                        fundo = .guepardo
                    default:
                        print("b")
                    }
                })
                .controlSize(.regular)
                .background(Color.black)
                .foregroundColor(.orange)
                .buttonStyle(.bordered)
                .cornerRadius(3.0)
                
                Text("\(velocidade)km/h").font(.system(size: 45))
                
                
                Image(img).resizable().scaledToFit().clipShape(Circle())
                
                ZStack{
                    RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    VStack{
                        HStack{
                            Text("TARTARUGA (0 - 9.9km/h)").foregroundColor(.white)}
                        HStack{
                            Text("ELEFANTE (10 - 29.9km/h)").foregroundColor(.white)
                        }
                        HStack{
                            Text("AVESTRUZ (30 -69.9km/h)").foregroundColor(.white)
                        }
                        HStack{
                            Text("LEÃO (70-89.9km/h)").foregroundColor(.white)
                        }
                        HStack{
                            Text("GUEPARDO (90 - 130km/h)").foregroundColor(.white)
                        }
                    }
                    
                }
                
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
